#!/bin/sh
# Copy-upgrade an LXC container using a new OCI image.
#
# Steps:
# 1) Verify source container exists and was created by oci-lxc-deployer (marker in description/notes).
# 2) Determine target VMID (existing or next free).
# 3) Output target VMID and installed addons for subsequent steps.
#
# Inputs (templated):
#   - source_vm_id (required)
#   - vm_id (optional target id)
#   - template_path (required; from 011-get-oci-image.json)
#   - ostype (optional; from 011-get-oci-image.json)
#   - oci_image (required; from 011-get-oci-image.json)
#
# Output:
#   - JSON to stdout: [{"id":"vm_id","value":"<target>"}, {"id":"installed_addons","value":"<addons>"}]

set -eu

SOURCE_VMID="{{ source_vm_id }}"
TARGET_VMID_INPUT="{{ vm_id }}"
TEMPLATE_PATH="{{ template_path }}"
OCI_IMAGE_RAW="{{ oci_image }}"

CONFIG_DIR="/etc/pve/lxc"
SOURCE_CONF="${CONFIG_DIR}/${SOURCE_VMID}.conf"

log() { echo "$@" >&2; }
fail() { log "Error: $*"; exit 1; }

if [ -z "$SOURCE_VMID" ]; then
  fail "source_vm_id is required"
fi

if [ ! -f "$SOURCE_CONF" ]; then
  fail "Source container config not found: $SOURCE_CONF"
fi

if [ -z "$TEMPLATE_PATH" ] || [ "$TEMPLATE_PATH" = "NOT_DEFINED" ]; then
  fail "template_path is missing (expected from 011-get-oci-image.json)"
fi

SOURCE_DESC=$(extract_description "$SOURCE_CONF")
SOURCE_CONF_TEXT=$(cat "$SOURCE_CONF" 2>/dev/null || echo "")
SOURCE_DESC_DECODED=$(decode_url "$SOURCE_DESC")
SOURCE_CONF_TEXT_DECODED=$(decode_url "$SOURCE_CONF_TEXT")

if ! check_managed_marker "$SOURCE_DESC" "$SOURCE_DESC_DECODED" "$SOURCE_CONF_TEXT" "$SOURCE_CONF_TEXT_DECODED"; then
  fail "Source container does not look like it was created by oci-lxc-deployer (missing notes marker)."
fi

# Determine target VMID
if [ -z "$TARGET_VMID_INPUT" ] || [ "$TARGET_VMID_INPUT" = "" ]; then
  TARGET_VMID=$(pvesh get /cluster/nextid)
else
  TARGET_VMID="$TARGET_VMID_INPUT"
fi
log "Copy-upgrade prepared: source=$SOURCE_VMID target=$TARGET_VMID"

INSTALLED_ADDONS=$(extract_addons "$SOURCE_DESC$SOURCE_CONF_TEXT")
log "Installed addons from source: $INSTALLED_ADDONS"

printf '[{ "id": "vm_id", "value": "%s" }, { "id": "installed_addons", "value": "%s" }]' "$TARGET_VMID" "$INSTALLED_ADDONS"
